<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">HOME</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Media & Informasi</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Jurusan
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled"></a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

<nav id="navbar-example2" class="navbar bg-body-tertiary px-3 mb-3">
  <a class="navbar-brand" href="#"></a>
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a class="nav-link" href="#scrollspyHeading1">Absen</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#scrollspyHeading2">Tugas</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"></a>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="#scrollspyHeading3">Third</a></li>
        <li><a class="dropdown-item" href="#scrollspyHeading4">Fourth</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item" href="#scrollspyHeading5">Fifth</a></li>
      </ul>
    </li>
  </ul>
</nav>
<div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" class="scrollspy-example bg-body-tertiary p-3 rounded-2" tabindex="0">
  <h4 id="scrollspyHeading1">SMK MUHAMMADIYAH CIKAMPEK</h4>
  <p>SMK TI Muhammadiyah adalah salah satu dari beberapa sekolah menengah kejuruan swasta yang mengemban misi yang sama dalam mencerdaskan anak bangsa. Dalam kiprahnya selama 16 tahun sejak berdirinya tahun 2003, SMK TI Muhammadiyah Cikampek melaksanakan tugasnya sebagai pelaksana pendidikan tingkat menengah dan selama kurun waktu tersebut SMK TI Muhammadiyah Cikampek melakukan pembenahan dalam semua bidang.
</p>
<p>
    Untuk mengikuti pesatnya perkembangan industri dan teknologi pada saat ini, maka SMK TI Muhammadiyah Cikampek ikut menerapkan kebijakan dengan mempersiapkan diri dan berusaha meningkatkan mutu terutama di bidang teknologi industri tingkat menengah yang mampu menunjang pertumbuhan dan perkembangan teknologi industri dengan memanfaatkan serta mengembangkan segala potensi sumber daya yang ada untuk digunakan dalam proses teknologi industri baik secara teoritis maupun aplikatif, sehingga dapat dimanfaatkan dalam kehidupan bermasyarakat yang berjiwa wirausaha (enterpreneurship).
Seiring dengan perkembangan tersebut, SMK TI Muhammadiyah juga telah melakukan evaluasi diri guna mewujudkan kemandirian antara lain dengan mengkaji berbagai komponen, seperti kurikulum dan pembelajaran, administrasi dan manajemen, organisasi dan kelembagaan, sarana dan prasarana, ketenagaan, pembiayaan, dan pendanaan, peserta didik, peran serta masyarakat, serta lingkungan budaya, dan program keahlian.
</p><p>
Dalam mencapai sasaran yang telah diprogramkan dalam Rencana Strategis antara lain melalui penerapan Sistem Penjaminan Mutu Pendidikan yang akan dicanangkan bagi seluruh guru dan karyawan serta peserta didik SMK TI Muhammadiyah mulai tahun ini sebagai penerapan sekolah model dan sekolah rujukan. Dengan memanfaatkan semua potensi yang ada maka SMK TI Muhammadiyah diharapkan mampu menghasilkan lulusan dengan berbagai profil antara lain: Kompetensi umum mengacu kepada pendidikan nasional dan kecakapan hidup generik, sesuai tuntutan Undang Undang Sistem Pendidikan Nasional (UUSPN) pasal 3 meliputi : Beriman dan bertaqwa, Berahklak mulia, sehat, cakap, kreatif, mandiri, demokratis dan bertanggung jawab. Sedangkan sesuai tuntutan dunia kerja adalah disiplin dan jujur. Kompetensi kejuruan adalah kompetensi yang 
mengacu pada SKKNI Teknologi Rekayasa dan Teknologi Informasi dan Komunikasi</p>
  <h4 id="scrollspyHeading2  mb-8">JURUSAN </h4>
  <p>TEKNIK MESIN, TEKNIK KOMPUTER JARINGAN, TEKNIK SEPEDA MOTOR, PERKANTORAN, REKAYASA PERANGKAT LUNAK</p>
  <h4 id="scrollspyHeading3"></h4>
  <p></p>
  <h4 id="scrollspyHeading4"></h4>
  <p></p>
  <h4 id="scrollspyHeading5"></h4>
  <p></p>
</div>