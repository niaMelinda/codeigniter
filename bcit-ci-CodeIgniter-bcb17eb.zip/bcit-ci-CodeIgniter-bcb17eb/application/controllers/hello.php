<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hello extends CI_Controller {

	public function data($data)
	{
		echo $data;
	}
    public function tampil()
    {
        $data ['judul']= "judul";
        $data ['deskripsi']= "ini deskripsi";

        $this->load->view('tampil', $data);
        

    }
}