<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class catatan extends CI_Controller {

	public function index()
	{
		$data['query'] = $this->db->get('catatanperjalanan')->result();
		$this->load->view('view_catatan', $data);
	}
}