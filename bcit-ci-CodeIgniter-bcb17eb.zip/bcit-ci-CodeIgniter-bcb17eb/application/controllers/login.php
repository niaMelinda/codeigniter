<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <div class="card">
  <div class="card-header">
    LOGIN
  </div>
  <div class="card-body">
  <div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">NIS</label>
  <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="">
  </div>

  <div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">NAMA</label>
  <input type="variable" class="form-control" id="exampleFormControlInput1" placeholder="">
  </div>

  <div class="mb-3">
      <label for="disabledSelect" class="form-label">KELAS</label>
      <select id="disabledSelect" class="form-select"> 
        <option>TEKNIK MESIN
        <option>TEKNIK KOMPUTER JARINGAN 
        <option>TEKNIK SEPEDA MOTOR
        <option>PERKANTORAN
        <option>REKAYASA PERANGKAT LUNAK

        </option>
      </select>
    </div>

<br>
<button type="button" class="btn btn-primary btn-block mb-4">LOGIN</button>

<div class="text-center">
  <p>Not a member? <a href="#!">Register</a></p>
<br>

<?php
?>
</form>

</div>
</div>
</body>
</html>