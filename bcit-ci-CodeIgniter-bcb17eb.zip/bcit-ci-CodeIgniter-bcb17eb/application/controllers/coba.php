<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class coba extends CI_Controller {

	public function niaaa()
	{
        $query = $this->db->get('tbtagihan');
		foreach($query->result() as $row)
	    {
        // echo $row->idtagihan . "<br />";

        $this->load->view_data('tampil', $data);
   
        }
    }
}