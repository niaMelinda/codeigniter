<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>ini data</h1>
</body>
</html>

    <table border="1">
        <tr>
            <th>id_perjalanan</th>
            <th>id_login</th>
            <th>tanggal</th>
            <th>jam</th>
            <th>lokasi</th>
            <th>suhu_tubuh</th>
        </tr> 
        <?php foreach ($query as $query){ ?>
            <tr>
                <td><?=$query->id_perjalanan ?></td>
                <td><?=$query->id_login ?></td>
                <td><?=$query->tanggal ?></td>
                <td><?=$query->jam ?></td>
                <td><?=$query->lokasi ?></td>
                <td><?=$query->suhut_ubuh ?></td>
        </tr>
    <?php  } ?>
</table>
</body>
</html>